#!/usr/bin/env bash
# Removes CapeOS and its launcher entries. Your browser profile for CapeOS is removed too.
DEST="${CAPEOS_DIR:-$HOME/CapeOS}"
rm -f "$HOME/.config/autostart/capeos.desktop" "$HOME/.local/share/applications/capeos.desktop" "$HOME/Desktop/CapeOS.desktop"
rm -rf "$HOME/.config/capeos-chromium"
( sleep 1; rm -rf "$DEST" ) &
echo "CapeOS removed."
