/* Core: DOM helpers, persistence, shared state, notifications, modals, shared UI helpers */
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
const APPS={};
/** Replace an element's HTML only when it changed (avoids needless DOM work and lost hover/focus). */
const setHTML=(el,h)=>{if(el._h!==h){el._h=h;el.innerHTML=h}};
/** App icon tile; `id` is an app id or "trash". */
const tile=(id,s)=>`<span class="tile" data-app="${id}"${s?` style="--s:${s}px"`:""}>${I(id==="trash"?"trash":APPS[id].i)}</span>`;
/* ---- persistence (safe against disabled/full/corrupt storage) ---- */
const store={get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}},del(k){try{localStorage.removeItem(k)}catch(e){}}};
/* ---- appearance data ---- */
const SUNSET='url("data:image/svg+xml,'+encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1600 1000' preserveAspectRatio='xMidYMid slice'><defs><linearGradient id='s' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#1f2a25'/><stop offset='.35' stop-color='#4a4a26'/><stop offset='.58' stop-color='#d4a838'/><stop offset='.6' stop-color='#5c5a2a'/><stop offset='1' stop-color='#0d1311'/></linearGradient><radialGradient id='g' cx='.57' cy='.38' r='.3'><stop offset='0' stop-color='#fff3b0' stop-opacity='.9'/><stop offset='.25' stop-color='#f2c94c' stop-opacity='.45'/><stop offset='1' stop-color='#f2c94c' stop-opacity='0'/></radialGradient><filter id='b'><feGaussianBlur stdDeviation='14'/></filter></defs><rect width='1600' height='1000' fill='url(#s)'/><rect width='1600' height='1000' fill='url(#g)'/><g filter='url(#b)' fill='#e9c65a' opacity='.5'><ellipse cx='700' cy='430' rx='360' ry='20'/><ellipse cx='1050' cy='500' rx='430' ry='16'/><ellipse cx='500' cy='520' rx='300' ry='12'/></g><circle cx='910' cy='380' r='13' fill='#fff7c9'/><g stroke='#e9c65a' stroke-opacity='.3' stroke-width='3'><path d='M620 700h300M700 730h280M560 770h260M760 800h240M640 840h200'/></g><path d='M1600 560 1540 566 1500 590 1450 596 1420 630 1340 640 1290 676 1210 686 1170 720 1240 740 1230 790 1300 830 1330 1000 1600 1000z' fill='#0b100e'/></svg>")+'") center/cover';
const WALLS=[SUNSET,"radial-gradient(60% 60% at 80% 10%,#ff7a59cc,transparent),radial-gradient(70% 60% at 15% 90%,#c026d3aa,transparent),#14091f","radial-gradient(70% 60% at 30% 100%,#0ea5e9cc,transparent),radial-gradient(60% 50% at 80% 0%,#1e3a8a,transparent),#06121f","radial-gradient(60% 60% at 20% 20%,#22c55e88,transparent),radial-gradient(60% 60% at 90% 90%,#0f766eaa,transparent),#07130d","linear-gradient(160deg,#2b2d33,#0e0f12)","radial-gradient(60% 50% at 20% 10%,#fde68a,transparent),radial-gradient(60% 60% at 90% 90%,#fda4af,transparent),#e8eef7"];
const ACCS=["#5b8def","#4fd1b5","#f2b84b","#ff7a6b","#b28cff","#8bd450"];
/* ---- state: DEF = persisted, DEV = simulated device state (reset on reload) ---- */
const DEF={dark:true,br:100,vol:60,acc:ACCS[0],wall:0,sc:1,mot:false,hc:false,night:false,dockSm:false,saver:false,nsnd:true,res:"1920 × 1080",hz:60,widgets:true,wo:["clock","battery","weather","notes","status"],qn:"",
 engine:"ddg",home:"cape://home",bmBar:true,welcomed:false,dpos:{},inst:[],
 notes:[{id:1,body:"Welcome to CapeOS\nEverything here is simulated and stays on this device.",ts:Date.now()}],events:{},
 fs:[{id:1,name:"Documents",p:0,f:1},{id:2,name:"Pictures",p:0,f:1},{id:3,name:"Projects",p:0,f:1},{id:4,name:"budget.csv",p:1,s:"12 KB"},{id:5,name:"resume.pdf",p:1,s:"84 KB"},{id:6,name:"cape-ideas.txt",p:3,s:"2 KB",body:"Ideas for CapeOS:\n- Privacy dashboard\n- Widgets you can move around"},{id:100,name:"Desktop",p:0,f:1,sys:1},{id:101,name:"Downloads",p:0,f:1,sys:1}],
 perm:{Meetly:{cam:1,mic:1,loc:0,files:0,photos:0},Waypoint:{cam:0,mic:0,loc:1,files:0,photos:0},Scribbl:{cam:0,mic:0,loc:0,files:1,photos:0},Photon:{cam:1,mic:0,loc:0,files:0,photos:1}},log:[],
 todos:[{id:1,t:"Try the Demo Actions panel",d:0},{id:2,t:"Plug in the phone and open Files",d:0}],
 bm:[{t:"Wikipedia",u:"https://en.wikipedia.org"},{t:"Example",u:"https://example.com"}],hist:[],dl:[]};
const DEV={pw:"boot",locked:true,bat:76,chg:false,wifi:true,bt:true,air:false,net:true,dnd:false,rec:false,phone:false,usb:false,mon:false,hp:false,btd:false,prox:false,port:false,cam:false,mic:false,notifs:[],out:"Speakers"};
const PK=Object.keys(DEF);let S,lastSaved="";
/** Settings categories that "Restore defaults" resets; everything else is user data and is kept. */
const KEEP=["notes","events","fs","perm","log","todos","inst","welcomed","bm","hist","dl","qn"];
const resetSettings=()=>PK.filter(k=>!KEEP.includes(k)).forEach(k=>S[k]=structuredClone(DEF[k]));
function load(){const p=store.get("capeos",{});S=Object.assign(structuredClone(DEF),p&&typeof p==="object"?p:{},structuredClone(DEV));
 for(const id of [100,101])if(!S.fs.some(f=>f.id===id))S.fs.push(structuredClone(DEF.fs.find(f=>f.id===id)))}
function save(){const o={};PK.forEach(k=>o[k]=S[k]);const j=JSON.stringify(o);if(j!==lastSaved&&store.set("capeos",o))lastSaved=j}
load();
/* ---- small helpers ---- */
const time=d=>(d||new Date()).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),dstr=d=>(d||new Date()).toLocaleDateString([],{weekday:"long",day:"numeric",month:"long"});
const wifiOn=()=>S.wifi&&!S.air,btOn=()=>S.bt&&!S.air,online=()=>wifiOn()&&S.net;
function notify(app,title,body){S.notifs.unshift({id:Date.now()+Math.random(),app,title,body,t:Date.now(),read:false});S.notifs=S.notifs.slice(0,60);if(!S.dnd&&S.pw==="on"){const t=document.createElement("div");t.className="nt";t.innerHTML=`<small>${esc(app)}</small><div><b>${esc(title)}</b></div><small>${esc(body)}</small>`;$("#toasts").prepend(t);setTimeout(()=>t.remove(),4200)}}
const toast=m=>notify("System",m,"");
function logA(app,what){S.log.unshift({app,what,t:Date.now()});S.log=S.log.slice(0,25)}
function modal(title,body,btns){$("#modal")?.remove();const m=document.createElement("div");m.id="modal";m.innerHTML=`<div><h3 style="margin-bottom:8px">${title}</h3><p class="mu" style="margin-bottom:18px">${body}</p><div style="display:flex;gap:8px;justify-content:flex-end"></div></div>`;btns.forEach(([l,fn,pr])=>{const b=document.createElement("button");b.textContent=l;if(pr)b.className="p";b.onclick=()=>{m.remove();fn&&fn()};m.firstChild.lastChild.append(b)});$("#screen").append(m)}
const ask=(t,b,ok,fn)=>modal(t,b,[["Cancel"],[ok,fn,1]]);
const need=(c,m)=>{if(!c){toast(m);return 1}};
/* ---- shared UI builders (settings rows, toggles, sliders) ---- */
const tg=k=>`<button class="tg ${S[k]?"on":""}" data-a="tg" data-v="${k}" role="switch" aria-checked="${!!S[k]}"></button>`;
const rw=(l,c,s)=>`<div class="row"><div>${l}${s?`<br><small>${s}</small>`:""}</div><div>${c}</div></div>`;
const sl=(k,min,max,st)=>`<input type="range" min="${min}" max="${max}" step="${st||1}" value="${S[k]}" oninput="S['${k}']=+this.value;theme();renderBar();save();this.title=this.value" style="width:140px">`;
const outs=()=>["Speakers",S.hp&&"Headphones",btOn()&&S.btd&&"CapeBuds (Bluetooth)"].filter(Boolean),getOut=()=>outs().includes(S.out)?S.out:"Speakers";
