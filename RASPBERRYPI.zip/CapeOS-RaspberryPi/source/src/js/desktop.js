/* Desktop: icons (select, drag, open), desktop context menu */
let selK=null;
function openItem(k){if(k.startsWith("app:"))open(k.slice(4));else if(k==="trash")filesGo("trash");else openFile(fsFind(k.slice(3)))}
function renderDesk(){const bx=$("#icons"),cw=bx.clientWidth,ch=bx.clientHeight,rows=Math.max(1,Math.floor(ch/110));
 const it=[...[["files","Files"],["cbrowser","Browser"],["notes","Notes"],["privacy","Privacy"],["store","App Store"]].map(([k,n])=>({k:"app:"+k,n,t:tile(k)})),{k:"trash",n:"Trash",t:tile("trash")},...S.fs.filter(f=>f.p===100&&!f.tr).map(f=>({k:"fs:"+f.id,n:f.name,t:`<span class="tile ${f.f?"fol":"fil"}">${I(f.f?"fold":"note")}</span>`}))];
 setHTML(bx,it.map((x,i)=>{const p=S.dpos[x.k]||[cw-(Math.floor(i/rows)+1)*104,8+(i%rows)*110];return `<div class="di ${selK===x.k?"sel":""}" data-k="${x.k}" style="left:${Math.max(0,Math.min(p[0],cw-92))}px;top:${Math.max(0,Math.min(p[1],ch-100))}px">${x.t}<span class="l">${esc(x.n)}</span></div>`}).join(""))}
{const bx=$("#icons"),sel=k=>{selK=k;bx.querySelectorAll(".di").forEach(x=>x.classList.toggle("sel",x.dataset.k===k))};
bx.addEventListener("pointerdown",e=>{const d=e.target.closest(".di");if(!d||e.button)return;sel(d.dataset.k);const sx=e.clientX,sy=e.clientY,ox=d.offsetLeft,oy=d.offsetTop;let mv=0;d.setPointerCapture(e.pointerId);
d.onpointermove=m=>{if(!mv&&Math.hypot(m.clientX-sx,m.clientY-sy)<5)return;mv=1;d.style.left=Math.max(0,Math.min(bx.clientWidth-88,ox+m.clientX-sx))+"px";d.style.top=Math.max(0,Math.min(bx.clientHeight-90,oy+m.clientY-sy))+"px"};
d.onpointerup=()=>{d.onpointermove=d.onpointerup=null;if(mv){S.dpos[d.dataset.k]=[d.offsetLeft,d.offsetTop];save()}else if(matchMedia("(pointer:coarse)").matches)openItem(d.dataset.k)}});
bx.addEventListener("dblclick",e=>{const d=e.target.closest(".di");if(d)openItem(d.dataset.k)});
bx.addEventListener("contextmenu",e=>{const d=e.target.closest(".di");if(!d)return;e.preventDefault();e.stopPropagation();const k=d.dataset.k;sel(k);const f=k.startsWith("fs:")&&fsFind(k.slice(3));ctxMenu(e.clientX,e.clientY,[["Open",()=>openItem(k)],...(f?[["Rename",()=>ren(f)],["Duplicate",()=>dupIt(f)],["Move to Trash",()=>trashIt(f)]]:[]),...(k==="trash"?[["Empty Trash",emptyTrash]]:[])])});
$("#desk").addEventListener("click",()=>sel(null));
$("#desk").addEventListener("contextmenu",e=>{e.stopImmediatePropagation();e.preventDefault();sel(null);ctxMenu(e.clientX,e.clientY,[["New Folder",()=>newFolder(100)],["New Text File",()=>newText(100)],["New Note",()=>{open("notes")}],["Clean Up Icons",()=>{S.dpos={};save();renderDesk()}],["Change Wallpaper",()=>{ACT.sec("Personalization");emit()}],["Display Settings",()=>{ACT.sec("Display");emit()}],["Lock Screen",()=>{ACT.lockNow();emit()}]])},true)}
{let raf;new ResizeObserver(()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(renderDesk)}).observe($("#icons"))}

