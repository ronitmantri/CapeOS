/* Startup */
S.inst=S.inst.filter(id=>APPS[id]&&APPS[id].store); // drop ids of apps that no longer exist or became built-in
document.addEventListener("keydown",e=>{if(e.key==="Escape")$("#modal")?.remove()});
renderDock();theme();renderPanel();setPw("boot");
