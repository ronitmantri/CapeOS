/* Sound: generative music player (Web Audio). Volume and output follow system state. */
let MA,Mi,Mt,Mn=0,Mp=0,Mel=0,Mc;const TLEN=200;
const TR=[["Blue Hour","Arlo June","Northern Tides",[0,4,7,12,7,4],220,420,"triangle"],["Night Bus","Kite & Ash","Paper Maps",[0,3,7,10,7,3],196,360,"triangle"],["Tidepool","Mire","Low Tide",[0,2,7,9,7,2],262,480,"triangle"],["Static Bloom","Hollow Lines","Signal",[0,7,12,7,3,10],174,300,"sawtooth"]];
const mDraw=()=>{if(Mc&&Mc.isConnected)APPS.music.r(Mc);if($("#cc"))ccR()};
function mStop(){clearInterval(Mi);clearInterval(Mt);Mp=0}
function mPlay(){try{MA=MA||new(window.AudioContext||window.webkitAudioContext)();MA.resume&&MA.resume()}catch(e){return notify("Sound","Audio unavailable","This browser blocked audio playback.")}
 Mp=1;const t=TR[Mn];let k=0;clearInterval(Mi);clearInterval(Mt);
 Mi=setInterval(()=>{if(S.pw!=="on"||S.vol<1)return;const j=k++,o=MA.createOscillator(),g=MA.createGain(),n=MA.currentTime;o.type=t[6];o.frequency.value=t[4]*2**(t[3][j%t[3].length]/12)*(j%8===0?.5:1);g.gain.setValueAtTime(0,n);g.gain.linearRampToValueAtTime(.18*S.vol/100,n+.03);g.gain.exponentialRampToValueAtTime(.0001,n+.6);o.connect(g);g.connect(MA.destination);o.start();o.stop(n+.65)},t[5]);
 Mt=setInterval(()=>{if(S.pw!=="on")return;if(++Mel>=TLEN)return mSel(Mn+1);const f=Mc&&Mc.querySelector(".prg i");if(f)f.style.width=Mel/TLEN*100+"%"},1000)}
const mSel=i=>{Mn=(i+TR.length)%TR.length;Mel=0;if(Mp)mPlay();mDraw()};
const mToggle=()=>{Mp?mStop():mPlay();mDraw()};
APPS.music={t:"Sound",i:"music",w:440,h:620,live:1,close:mStop,r(c){Mc=c;const t=TR[Mn];
 c.innerHTML=`<div class="snd"><div class="art"><span>CAPE</span></div><small class="np">NOW PLAYING</small><h2>${t[0]}</h2><p class="mu">${t[1]} · ${t[2]}</p><div class="prg" title="Seek"><i style="width:${Mel/TLEN*100}%"></i></div><div class="ctl"><button class="sk" data-m="p" aria-label="Previous">${I("prev",22)}</button><button class="pl" data-m="t" aria-label="${Mp?"Pause":"Play"}">${I(Mp?"pause":"play")}</button><button class="sk" data-m="n" aria-label="Next">${I("next",22)}</button></div><small class="mu" style="margin-top:18px">${S.vol===0?"Muted. Use volume up in Demo Actions.":`Playing on ${getOut()} · volume ${S.vol}%`}</small></div>`;
 c.querySelector("[data-m=p]").onclick=()=>mSel(Mn-1);c.querySelector("[data-m=n]").onclick=()=>mSel(Mn+1);c.querySelector("[data-m=t]").onclick=mToggle;
 c.querySelector(".prg").onclick=e=>{const r=e.currentTarget.getBoundingClientRect();Mel=Math.round((e.clientX-r.left)/r.width*TLEN);mDraw()}}};
