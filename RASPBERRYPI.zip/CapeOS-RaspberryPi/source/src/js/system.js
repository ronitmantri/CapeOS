/* System: power & lock, system bar, Demo Actions, windows, dock, overlays, actions */
const W={};let zi=10,foc=null,recent=[];
const D={}; // simulated device actions (Demo Actions panel, Terminal, Control Center)
const closeOverlays=()=>["#cc","#nc","#sw","#start","#ctx"].forEach(s=>$(s)?.remove());
function ctxMenu(x,y,items){$("#ctx")?.remove();const r=$("#screen").getBoundingClientRect(),m=document.createElement("div");m.id="ctx";m.style.cssText=`left:${Math.max(4,Math.min(x-r.left,r.width-204))}px;top:${Math.max(40,Math.min(y-r.top,r.height-items.length*34-16))}px`;items.forEach(([l,fn])=>{const b=document.createElement("button");b.textContent=l;b.onclick=fn;m.append(b)});$("#screen").append(m)}
function toggleOverlay(id,render){const o=$("#"+id);["#cc","#nc","#start"].forEach(s=>$(s)?.remove());if(o)return;const c=document.createElement("div");c.id=id;$("#screen").append(c);render(c)}
/* ---------- Power, boot, lock ---------- */

function setPw(p){S.pw=p;["boot","lock","off","sleep"].forEach(n=>$("#"+n).hidden=true);$("#prox").hidden=!(S.prox&&p==="on");
 if(p==="boot"){const b=$("#boot");b.hidden=false;b.innerHTML=LOGO(96)+`<div style="letter-spacing:.3em;font-weight:600">CAPEOS</div><div class="pb"><i></i></div><div class="mu" style="font-size:.85em">Starting up. Nothing leaves this device unless you say so.</div>`;setTimeout(()=>{if(S.pw==="boot"){S.locked=true;setPw("on");lockShow()}},3000)}
 if(p==="off"){const o=$("#off");o.hidden=false;o.innerHTML=`<button class="p" data-a="poweron" style="padding:14px 18px">${I("pwr",22)}<br>Turn on CapeOS</button>`}
 if(p==="sleep")$("#sleep").hidden=false;
 if(p==="on"){lockShow();renderDesk();if(!S.welcomed)showWelcome()}
 emit()}
function shutSeq(next){const o=$("#off");S.pw="down";o.hidden=false;o.innerHTML=LOGO(60)+`<div class="mu">${next?"Restarting":"Shutting down"}…</div>`;S.chg=false;setTimeout(()=>next?setPw("boot"):setPw("off"),2200)}
function lockShow(){const l=$("#lock");l.hidden=!S.locked;if(!S.locked)return;l.style.background=WALLS[S.wall];l.innerHTML=`<div>${I("lock",20)}<div style="margin-top:8px">${dstr()}</div><div class="clk" id="lclk">${time()}</div></div><div id="lnot" style="width:min(340px,100%);display:grid;gap:8px"></div><div><div>${batIcon()} ${Math.round(S.bat)}%${S.chg?" · Charging":""}</div><div style="margin-top:8px;opacity:.8">Click or swipe up to unlock</div></div>`;lockNot()}
function lockNot(){const e=$("#lnot");if(!e)return;e.innerHTML=S.dnd?"":S.notifs.slice(0,3).map(n=>`<div class="nt" style="color:var(--tx);text-shadow:none;text-align:left"><small>${n.app}</small><div><b>${n.title}</b></div><small>${n.body}</small></div>`).join("")}
let sy=0;$("#lock").addEventListener("pointerdown",e=>sy=e.clientY);$("#lock").addEventListener("pointerup",e=>{if(Math.abs(e.clientY-sy)>30||Math.abs(e.clientY-sy)<5)unlock()});
let hinted=false;
function unlock(){S.locked=false;$("#lock").hidden=true;if(!hinted){hinted=true;setTimeout(()=>{if(S.pw==="on"&&!S.locked)notify("Privacy","Waypoint wants your location","Open Privacy settings to allow or deny.")},9000);setTimeout(()=>{if(S.pw==="on")notify("System","Update available","CapeOS 1.0.1 is ready. Open Settings > System.")},20000)}emit()}
let wIv;
function showWelcome(){if($("#welcome"))return;const w=document.createElement("div");w.id="welcome";w.style.background=WALLS[S.wall];
const G=["Welcome","Bienvenue","Bienvenido","ようこそ","Willkommen","Benvenuto"];let gi=0;
w.innerHTML=`<div class="wl">${LOGO(84)}</div><div class="wm wl" style="animation-delay:.1s">CAPEOS</div><h1 id="wg" class="wl" style="animation-delay:.2s">${G[0]}</h1><p class="wl" style="animation-delay:.3s">CapeOS is a calm, private operating system. It brings together thoughtful design, everyday simplicity and the freedom to make it your own, without giving up your privacy to get there.</p>
<div class="wf"><div>${I("shield")}<b>Private by design</b><span>See what every app can reach, and revoke it in one tap.</span></div><div>${I("gear")}<b>Yours to shape</b><span>Choose your wallpaper, accent colour, widgets and layout.</span></div><div>${I("grid")}<b>Simple to use</b><span>Windows, a dock and apps that feel familiar from the first minute.</span></div></div>
<button class="p wl" id="wgo" style="padding:13px 34px;font-size:1.05em;border-radius:999px;animation-delay:.45s">Get started</button>
<small class="wl" style="animation-delay:.55s">This is a demo. Devices, battery and network are simulated. Use the DEMO ACTIONS tab on the right to plug in a phone, change the network and more.</small>`;
$("#screen").append(w);wIv=setInterval(()=>{const h=$("#wg");if(!h)return clearInterval(wIv);h.style.opacity=0;setTimeout(()=>{if(h.isConnected){h.textContent=G[++gi%G.length];h.style.opacity=1}},400)},2600);
const done=()=>{clearInterval(wIv);document.removeEventListener("keydown",kh);S.welcomed=true;S.locked=false;lockShow();save();w.classList.add("out");setTimeout(()=>w.remove(),500)},kh=e=>{if(e.key==="Enter"){e.preventDefault();done()}};
document.addEventListener("keydown",kh);w.querySelector("#wgo").onclick=done;setTimeout(()=>w.querySelector("#wgo").focus(),900)}
/* ---------- System bar ---------- */
const MINI_LOGO='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3c4 0 7 2 8 6-1 5-3 9-8 12-5-3-7-7-8-12 1-4 4-6 8-6zM12 3v18"/></svg>';

function batIcon(){const c=S.bat<=15?"#ff6b6b":S.chg?"var(--acc)":"currentColor";return `<svg class="i" viewBox="0 0 28 14" style="width:26px;height:13px;stroke:${c}"><rect x="1" y="1" width="23" height="12" rx="3"/><path d="M26 5v4"/><rect x="3" y="3" width="${Math.max(1,S.bat/100*19)}" height="8" rx="1" fill="${c}" stroke="none"/></svg>${S.chg?I("zap",12):""}`}
function renderBar(){const app=foc&&APPS[foc]?APPS[foc].t:"Desktop",un=S.notifs.some(n=>!n.read),d=new Date();
 setHTML($("#bar"),`<button class="bl" data-a="sysmenu" title="CapeOS menu">${MINI_LOGO}</button><b>CapeOS</b><span class="mu">${esc(app)}</span><span class="bc"><b>${time(d)}</b><small>${d.toLocaleDateString([],{day:"numeric",month:"short"})}</small></span><span class="sp"></span>${S.rec?'<span class="chip rec">● REC</span>':""}<button class="chip" data-a="app" data-v="privacy" title="Privacy dashboard">${I("shield",15)}${S.cam?'<i class="dot" style="background:#4cd964"></i>Camera on':S.mic?'<i class="dot" style="background:#ff9f0a"></i>Microphone on':"Protected"}</button><button class="ib" data-a="nc" title="Notifications">${I("bell",17)}${un?'<i class="nd"></i>':""}</button><button class="grp" data-a="cc" title="Control Center">${S.air?I("plane",15):""}<span style="opacity:${wifiOn()?1:.35}">${I("wifi",15)}</span>${wifiOn()&&!S.net?'<small class="warn">No internet</small>':""}<span style="opacity:${btOn()?1:.35}">${I("bt",15)}</span>${batIcon()}<small>${Math.round(S.bat)}%</small></button>`)}

/* ---------- Demo Actions panel & widgets ---------- */
const G=[["Power and charging",[["Plug in charger","chgOn",()=>S.chg],["Unplug charger","chgOff",()=>!S.chg],["Charge to 100%","full"],["Simulate low battery","low"],["Restart device","restart"],["Shut down device","shut"],["Wake device","wake",()=>S.pw!=="sleep"],["Put device to sleep","sleep",()=>S.pw!=="on"]]],
["Physical connectivity",[["Plug in phone","phoneOn",()=>S.phone],["Unplug phone","phoneOff",()=>!S.phone],["Connect USB drive","usbOn",()=>S.usb],["Eject USB drive","usbOff",()=>!S.usb],["Connect external monitor","monOn",()=>S.mon],["Disconnect external monitor","monOff",()=>!S.mon],["Connect headphones","hpOn",()=>S.hp],["Disconnect headphones","hpOff",()=>!S.hp],["Connect Bluetooth device","btdOn",()=>S.btd||!btOn()],["Disconnect Bluetooth device","btdOff",()=>!S.btd]]],
["Sensors and physical interactions",[["Cover proximity sensor","proxOn",()=>S.prox],["Uncover proximity sensor","proxOff",()=>!S.prox],["Rotate device","rotate"],["Shake device","shake"],["Press power button","pwrBtn"],["Press volume up","vu"],["Press volume down","vd"],["Enable camera","camOn",()=>S.cam],["Disable camera","camOff",()=>!S.cam],["Enable microphone","micOn",()=>S.mic],["Disable microphone","micOff",()=>!S.mic]]],
["Network simulation",[["Disconnect Wi-Fi","wifiOff",()=>!S.wifi],["Reconnect Wi-Fi","wifiOn",()=>S.wifi],["Disconnect internet","netOff",()=>!S.net],["Restore internet","netOn",()=>S.net],["Enable airplane mode","airOn",()=>S.air],["Disable airplane mode","airOff",()=>!S.air]]],
["Demo management",[["Reset demo","resetAll"],["Reset all settings","resetSet"],["Restore default battery","defBat"],["Disconnect all devices","discAll"],["Restore default state","resetDev"]]]];
function renderPanel(){if(!document.body.classList.contains("pan"))return;const pb=$("#pb"),y=pb.scrollTop;const st=[["Charger",S.chg],["Phone",S.phone],["USB drive",S.usb],["Monitor",S.mon],["Headphones",S.hp],["Bluetooth device",S.btd],["Proximity",S.prox],[S.port?"Portrait":"Landscape",S.port],["Camera",S.cam],["Mic",S.mic],["Wi-Fi",wifiOn()],["Internet",online()],["Airplane",S.air]];
pb.innerHTML=`<h3 style="margin-top:0">Device status</h3><div class="st">${st.map(([n,o])=>`<span class="${o?"on":""}">${n}: ${o?"on":"off"}</span>`).join("")}<span class="on">Battery ${Math.round(S.bat)}%</span><span class="on">Power: ${S.pw}</span></div>`+G.map(([t,b])=>`<h3>${t}</h3><div class="bt">${b.map(([l,a,d])=>`<button data-a="d:${a}" ${d&&d()?"disabled":""}>${l}</button>`).join("")}</div>`).join("");pb.scrollTop=y}
const WG={clock:()=>`<small>Clock</small><div class="big">${time()}</div><small>${dstr()}</small>`,battery:()=>`<small>Battery</small><div class="big">${Math.round(S.bat)}%</div><div class="meter"><i style="width:${S.bat}%;background:${S.bat<=15?"#ff6b6b":"var(--acc)"}"></i></div><small>${S.chg?"Charging":"On battery"}${S.saver?" · Saver on":""}</small>`,weather:()=>`<small>Weather · simulated</small><div class="big">24°</div><small>Partly cloudy, Cape City</small>`,notes:()=>`<small>Quick note</small><textarea id="qn" rows="3" placeholder="Jot something down" oninput="S.qn=this.value;save()">${S.qn}</textarea>`,status:()=>`<small>System status</small><div>${[["Wi-Fi",wifiOn()],["Internet",online()],["Bluetooth",btOn()]].map(([n,o])=>`${n}: ${o?"on":"off"}`).join(" · ")}</div><small>${[S.phone&&"Phone",S.usb&&"USB",S.mon&&"Monitor",S.hp&&"Headphones"].filter(Boolean).join(", ")||"No devices connected"}</small>`};
function renderWidgets(){const w=$("#widgets");w.hidden=!S.widgets;if(!S.widgets||document.activeElement?.id==="qn")return;setHTML(w,S.wo.map(k=>`<div class="wg">${WG[k]()}<button class="up" data-a="wup" data-v="${k}" title="Move up">${I("up",14)}</button></div>`).join(""))}
function theme(){const b=document.body,s=$("#screen"),dk=$("#desk"),bg=WALLS[S.wall]||WALLS[0];b.classList.toggle("light",!S.dark);b.classList.toggle("rm",S.mot);b.classList.toggle("hc",S.hc);b.classList.toggle("sm",S.dockSm);b.style.setProperty("--acc",S.acc);b.style.setProperty("--sc",S.sc);if(dk._w!==bg){dk._w=bg;dk.style.background=bg}s.classList.toggle("port",S.port);s.style.filter=`brightness(${S.br/100})${S.night?" sepia(.35)":""}`}

/* ---------- Windows & dock ---------- */
const DOCK=["files","cbrowser","notes","calc","gallery","cal","music","settings","store"];
function closeWin(id){const w=W[id];if(!w)return;w.el.remove();delete W[id];APPS[id].close?.();if(foc===id)foc=null;recent=recent.filter(x=>x!==id);renderDock();renderBar()}
function open(id){const A=APPS[id];if(!A)return;
 if(A.store&&!S.inst.includes(id))return modal("Get "+A.t+" first","Install it from the App Store.",[["Cancel"],["Open App Store",()=>open("store"),1]]);
 closeOverlays();
 if(W[id]){W[id].el.classList.remove("min");return focus(id)}
 const wins=$("#wins"),sw=wins.clientWidth,sh=wins.clientHeight,n=Object.keys(W).length,w=Math.min(A.w||640,sw-16),h=Math.min(A.h||440,sh-100),el=document.createElement("div");
 el.className="win";el.style.cssText=`left:${Math.max(8,Math.min(100+n*28,sw-w-8))}px;top:${Math.max(44,Math.min(56+n*26,sh-h-84))}px;width:${w}px;height:${h}px`;
 el.innerHTML=`<div class="tb"><span class="dots"><button data-w="x" title="Close" aria-label="Close"></button><button data-w="min" title="Minimize" aria-label="Minimize"></button><button data-w="max" title="Maximize" aria-label="Maximize"></button></span><b>${tile(id)}${esc(A.t)}</b><span class="tr"><button data-w="snap" title="Split screen" aria-label="Split screen">${I("cols",15)}</button></span></div><div class="wc"></div>`;
 wins.append(el);W[id]={el,c:el.querySelector(".wc")};A.r(W[id].c,id);focus(id);
 const tb=el.querySelector(".tb"),at=e=>{const r=wins.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]};
 tb.onpointerdown=e=>{if(e.target.closest("button")||el.classList.contains("max"))return;focus(id);const[px,py]=at(e),ox=el.offsetLeft,oy=el.offsetTop;tb.setPointerCapture(e.pointerId);el.classList.remove("sl","sr");
  tb.onpointermove=m=>{const[x,y]=at(m);el.style.left=Math.max(80-el.offsetWidth,ox+x-px)+"px";el.style.top=Math.max(36,oy+y-py)+"px"};tb.onpointerup=()=>{tb.onpointermove=tb.onpointerup=null}};
 tb.ondblclick=e=>{if(!e.target.closest("button"))el.classList.toggle("max")};el.addEventListener("pointerdown",()=>focus(id),true);
 tb.addEventListener("click",e=>{const a=e.target.closest("[data-w]")?.dataset.w;if(!a)return;
  if(a==="x")closeWin(id);else if(a==="min"){el.classList.add("min");if(foc===id)foc=null;renderBar()}else if(a==="max")el.classList.toggle("max");
  else{el.classList.remove("max");const c=el.classList.contains("sl")?"sr":el.classList.contains("sr")?"":"sl";el.classList.remove("sl","sr");c&&el.classList.add(c)}})}
function focus(id){const w=W[id];if(!w)return;foc=id;w.el.style.zIndex=++zi;recent=[id,...recent.filter(x=>x!==id)].slice(0,6);for(const[k,v]of Object.entries(W))v.el.classList.toggle("f",k===id);renderDock();renderBar()}
function renderDock(){setHTML($("#dock"),`<button class="dk lc" data-a="start" title="Start menu" aria-label="Start menu">${I("grid",20)}</button><i class="sep"></i>${DOCK.map(k=>`<button class="dk ${W[k]?"run":""}" data-a="app" data-v="${k}" title="${APPS[k].t}" aria-label="${APPS[k].t}">${tile(k)}</button>`).join("")}<i class="sep"></i><button class="dk" data-a="trash" title="Trash" aria-label="Trash">${tile("trash")}</button>`)}
/** Re-render one live window and keep every scroll position (lists, settings panes, file views). */
function renderApp(k){const w=W[k];if(!w)return;const all=()=>[w.c,...w.c.querySelectorAll("*")],sc=[];all().forEach((e,i)=>{if(e.scrollTop)sc.push([i,e.scrollTop])});APPS[k].r(w.c,k);if(sc.length){const n=all();sc.forEach(([i,t])=>{if(n[i])n[i].scrollTop=t})}}
const SIGK=Object.keys(DEV).filter(k=>k!=="bat"&&k!=="notifs");
/** Single refresh path for shared UI. Live windows only re-render when state they depend on changed, and never while typing in them. */
function emit(){save();theme();renderBar();renderDock();renderPanel();renderWidgets();lockNot();
 const ae=document.activeElement,typing=ae&&/INPUT|TEXTAREA/.test(ae.tagName),base=lastSaved+JSON.stringify(SIGK.map(k=>S[k]))+S.notifs.length;
 for(const[k,w]of Object.entries(W)){if(!APPS[k].live)continue;const sig=base+(k==="sysinfo"||(k==="settings"&&secV==="Battery")?Math.round(S.bat):"")+(k==="settings"?secV+upd+updP:"");if(w.sig===sig||(typing&&w.c.contains(ae)))continue;w.sig=sig;renderApp(k)}
 if($("#cc")&&!(ae&&ae.type==="range"))ccR();if($("#nc"))ncR()}
/** Keep windows inside the screen when it shrinks (Demo Actions panel, rotation, window resize). */
function clampWins(){const wins=$("#wins"),cw=wins.clientWidth,ch=wins.clientHeight;for(const{el}of Object.values(W)){if(["max","sl","sr","fsb"].some(c=>el.classList.contains(c)))continue;const wd=Math.min(el.offsetWidth,cw-16),ht=Math.min(el.offsetHeight,ch-90);el.style.width=wd+"px";el.style.height=ht+"px";el.style.left=Math.max(8,Math.min(el.offsetLeft,cw-wd-8))+"px";el.style.top=Math.max(40,Math.min(el.offsetTop,ch-ht-8))+"px"}}
{let raf;new ResizeObserver(()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(clampWins)}).observe($("#wins"))}

/* ---------- Simulated device actions ---------- */
setInterval(()=>{if(S.pw==="boot"||S.pw==="off")return;if(S.chg&&S.bat<100){S.bat=Math.min(100,S.bat+1);if(S.bat>=100){notify("Battery","Fully charged","You can unplug the charger.")}}else if(!S.chg&&S.bat>1&&Math.random()<(S.saver?.15:.3)){S.bat-=1;if(Math.round(S.bat)===15)notify("Battery","Low battery","15% left. Plug in a charger.")}emit()},3000);
Object.assign(D,{chgOn(){S.chg=true;notify("Battery","Charging","Charger connected. Charging started.")},chgOff(){S.chg=false;notify("Battery","Charger unplugged","Running on battery at "+Math.round(S.bat)+"%.")},full(){S.bat=100;S.chg=false;notify("Battery","Battery full","Set to 100%.")},low(){S.bat=8;S.chg=false;notify("Battery","Low battery: 8%","Plug in a charger or turn on Battery saver.");S.saver=true;modal("Low battery","8% remaining. Battery saver was turned on.",[["OK",0,1]])},
restart(){ask("Restart device?","CapeOS will shut down and start again.","Restart",()=>shutSeq(1))},shut(){ask("Shut down device?","CapeOS will power off.","Shut down",()=>shutSeq(0))},wake(){if(S.pw==="sleep")setPw("on")},sleep(){S.locked=true;setPw("sleep")},poweron(){setPw("boot")},
phoneOn(){S.phone=true;notify("Devices","Phone connected","Cape Phone is ready. Open Files to browse it.");open("files")},phoneOff(){S.phone=false;notify("Devices","Phone disconnected","Cape Phone was unplugged.")},
usbOn(){S.usb=true;notify("Devices","USB drive connected","CAPE-USB (64 GB) is available in Files.")},usbOff(){S.usb=false;notify("Devices","USB drive ejected","CAPE-USB can be safely removed.")},
monOn(){S.mon=true;notify("Display","External monitor connected","Cape View 27″ detected. See Settings > Display.")},monOff(){S.mon=false;notify("Display","External monitor disconnected","Using the built-in display.")},
hpOn(){S.hp=true;S.out="Headphones";notify("Sound","Headphones connected","Audio output switched to Headphones.")},hpOff(){S.hp=false;S.out="Speakers";notify("Sound","Headphones disconnected","Audio output is Speakers.")},
btdOn(){if(need(btOn(),"Turn on Bluetooth first"))return;S.btd=true;notify("Bluetooth","CapeBuds connected","Paired Bluetooth audio device.")},btdOff(){S.btd=false;notify("Bluetooth","CapeBuds disconnected","")},
proxOn(){S.prox=true;$("#prox").hidden=S.pw!=="on";notify("Sensors","Proximity sensor covered","Display turned off.")},proxOff(){S.prox=false;$("#prox").hidden=true;notify("Sensors","Proximity sensor uncovered","Display on.")},
rotate(){S.port=!S.port;notify("Display","Rotated to "+(S.port?"portrait":"landscape"),"")},shake(){const s=$("#screen");s.classList.remove("shake");void s.offsetWidth;s.classList.add("shake");notify("Sensors","Shake detected","Undo typing is not enabled in this demo.")},
pwrBtn(){if(S.pw==="sleep")setPw("on");else if(S.pw==="on"){S.locked=true;lockShow();notify("System","Screen locked","")}},vu(){S.vol=Math.min(100,S.vol+10)},vd(){S.vol=Math.max(0,S.vol-10)},
camOn(){if(!S.perm.Meetly.cam){notify("Privacy","Camera blocked","Meetly has no camera permission.");return}S.cam=true;logA("Meetly","Used the camera");notify("Privacy","Camera in use","Meetly is using the camera.")},camOff(){S.cam=false;notify("Privacy","Camera off","")},
micOn(){if(!S.perm.Meetly.mic){notify("Privacy","Microphone blocked","Meetly has no microphone permission.");return}S.mic=true;logA("Meetly","Used the microphone");notify("Privacy","Microphone in use","Meetly is using the microphone.")},micOff(){S.mic=false;notify("Privacy","Microphone off","")},
wifiOff(){S.wifi=false;notify("Network","Wi-Fi disconnected","CapeNet-5G is no longer connected.")},wifiOn(){if(need(!S.air,"Turn off airplane mode first"))return;S.wifi=true;notify("Network","Wi-Fi connected","Connected to CapeNet-5G.")},
netOff(){S.net=false;notify("Network","No internet","Wi-Fi is connected but there is no internet access.")},netOn(){S.net=true;notify("Network","Internet restored","")},
airOn(){S.air=true;S.btd=false;notify("Network","Airplane mode on","Wi-Fi and Bluetooth are off.")},airOff(){S.air=false;notify("Network","Airplane mode off","Radios restored.")},
resetAll(){ask("Reset demo?","This resets devices, settings, notes, files and events.","Reset",()=>{store.del("capeos");lastSaved="";Object.keys(W).forEach(closeWin);load();setPw("boot")})},
resetSet(){ask("Reset all settings?","Appearance, sound and display go back to default.","Reset",()=>{resetSettings();emit()})},
defBat(){S.bat=76;S.chg=false;notify("Battery","Battery restored","Default level: 76%.")},discAll(){Object.assign(S,{phone:false,usb:false,mon:false,hp:false,btd:false,out:"Speakers",cam:false,mic:false,prox:false});$("#prox").hidden=true;notify("Devices","All devices disconnected","")},
resetDev(){ask("Restore default state?","Devices, network and battery return to defaults.","Restore",()=>{Object.assign(S,structuredClone(DEV),{pw:"on",locked:false,notifs:S.notifs});$("#prox").hidden=true;emit()})}});
/* ---------- Start menu, Control Center, notification center ---------- */
const START_APPS=["files","cbrowser","notes","settings","music","calc"];
const QUICK=[["Turn on Focus","moon",()=>{S.dnd=true;toast("Focus is on")}],["Turn off Focus","moon",()=>{S.dnd=false}],["Switch to dark mode","moon",()=>{S.dark=true}],["Switch to light mode","sun",()=>{S.dark=false}],["Turn on Battery saver","zap",()=>{S.saver=true}],["Lock screen","lock",()=>ACT.lockNow()],["Open recent files","fold",()=>filesGo("home",100)],["Open privacy dashboard","shield",()=>open("privacy")],["New note","note",()=>open("notes")],["Check for updates","info",()=>ACT.sec("System")]];
function startR(m){let q="",mode="home",sel=0;const list=()=>Object.entries(APPS).filter(([k,a])=>!a.store||S.inst.includes(k));
 m.innerHTML=`<div class="sr">${I("search",18)}<input id="sq2" placeholder="Search apps, files, and actions" autocomplete="off" spellcheck="false"><kbd>esc</kbd></div><div class="sb"></div><div class="su"><span class="av">AM</span><b>Alex Morgan</b><button class="ib" data-a="powermenu" title="Power" aria-label="Power">${I("pwr",18)}</button></div>`;
 const sb=m.querySelector(".sb"),inp=m.querySelector("#sq2"),run=r=>{m.remove();r.fn();emit()};
 const results=()=>{const t=q.toLowerCase();return[...list().filter(([k,a])=>a.t.toLowerCase().includes(t)).map(([k,a])=>({l:a.t,k:"Application",app:k,fn:()=>open(k)})),...S.fs.filter(f=>!f.tr&&!f.sys&&!f.f&&f.name.toLowerCase().includes(t)).slice(0,5).map(f=>({l:f.name,k:"File",ic:"note",fn:()=>openFile(f)})),...QUICK.filter(x=>x[0].toLowerCase().includes(t)).map(x=>({l:x[0],k:"Action",ic:x[1],fn:x[2]}))]};
 let cur=[];const row=(r,i)=>`<button class="rs ${i===sel?"on":""}" data-i="${i}">${r.app?tile(r.app):`<span class="qi" style="width:30px;height:30px;border-radius:8px;background:var(--s3);display:grid;place-items:center">${I(r.ic,16)}</span>`}<span><b>${esc(r.l)}</b><br><small class="mu">${r.k}</small></span></button>`;
 const draw=()=>{if(q||mode==="qa"){cur=q?results():QUICK.map(x=>({l:x[0],k:"Action",ic:x[1],fn:x[2]}));sel=Math.min(sel,Math.max(0,cur.length-1));sb.innerHTML=(mode==="qa"&&!q?'<div class="sh"><small class="mu">Quick actions</small><button data-s="home">Back</button></div>':"")+(cur.map(row).join("")||`<p class="mu pad">No results for “${esc(q)}”.</p>`);sb.querySelectorAll(".rs").forEach(b=>b.onclick=()=>run(cur[+b.dataset.i]));sb.querySelector("[data-s]")?.addEventListener("click",()=>{mode="home";draw()});return}
  const ap=(mode==="all"?list():START_APPS.map(k=>[k,APPS[k]]));
  sb.innerHTML=`<div class="sh"><small class="mu"><b>Applications</b></small><button data-s="${mode==="all"?"home":"all"}">${mode==="all"?"Show less":"All apps"}</button></div><div class="sg">${ap.map(([k,a])=>`<button data-app="${k}">${tile(k)}<span>${esc(a.t)}</span></button>`).join("")}</div><button class="qa" data-s="qa"><span class="qi">${I("cmd",18)}</span><span><b>Quick actions</b><small>Try “turn on focus” or “open recent files”</small></span><span style="margin-left:auto" class="mu">${I("right",16)}</span></button>`;
  sb.querySelectorAll("[data-app]").forEach(b=>b.onclick=()=>run({fn:()=>open(b.dataset.app)}));sb.querySelectorAll("[data-s]").forEach(b=>b.onclick=()=>{mode=b.dataset.s;draw()})};
 inp.oninput=()=>{q=inp.value.trim();sel=0;draw()};
 inp.onkeydown=e=>{if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();sel=Math.max(0,Math.min(cur.length-1,sel+(e.key==="ArrowDown"?1:-1)));draw()}if(e.key==="Enter"&&q&&cur[sel])run(cur[sel]);if(e.key==="Escape")m.remove()};
 draw();inp.focus()}
function ccR(){const c=$("#cc");if(!c)return;const t=(k,ic,l,sub,on)=>`<button class="ct ${on?"on":""}" data-a="tg" data-v="${k}"><span class="ci">${I(ic,18)}</span><span><b>${l}</b><small>${sub}</small></span></button>`,s=(k,ic,l,on)=>`<button class="cs ${on?"on":""}" data-a="tg" data-v="${k}">${I(ic,18)}${l}</button>`,
 sd=(k,ic,l,min)=>`<div class="sc2"><div><span>${I(ic,15)}${l}</span><span>${S[k]}%</span></div><input type="range" min="${min}" max="100" value="${S[k]}" aria-label="${l}" oninput="S['${k}']=+this.value;theme();save();this.previousElementSibling.lastChild.textContent=this.value+'%'"></div>`,tr=TR[Mn];
 c.innerHTML=`<div class="ch"><div><small>CONTROL CENTER</small><h3>Your Cape</h3></div><button class="ib" data-a="sec" data-v="Connectivity" title="Settings" aria-label="Settings">${I("gear",18)}</button></div>
 <div class="cg">${t("wifi","wifi","Wi-Fi",wifiOn()?(S.net?"CapeNet-5G":"No internet"):"Off",wifiOn())}${t("bt","bt","Bluetooth",btOn()?(S.btd?"CapeBuds":"On"):"Off",btOn())}${t("dnd","moon","Focus",S.dnd?"On":"Off",S.dnd)}${t("dark",S.dark?"moon":"sun","Theme",S.dark?"Dark":"Light",S.dark)}</div>
 <div class="cg cg2">${s("air","plane","Airplane",S.air)}${s("saver","zap","Saver",S.saver)}${s("rec","rec","Record",S.rec)}<button class="cs" data-a="lockNow">${I("lock",18)}Lock</button></div>
 ${sd("br","sun","Display",30)}${sd("vol","vol","Sound",0)}
 <div class="cm"><span class="art2">${tr[0].split(" ").map(w=>w[0]).join("")}</span><span><b>${tr[0]}</b><small>${tr[1]}</small></span><button class="pl" data-a="mtog" aria-label="${Mp?"Pause":"Play"}">${I(Mp?"pause":"play",16)}</button></div>
 <p class="mu" style="font-size:.75em;margin-top:10px">Simulated controls. They do not change real hardware.</p>`}

function ncR(){const c=$("#nc");if(!c)return;const gr={};S.notifs.forEach(n=>(gr[n.app]=gr[n.app]||[]).push(n));c.innerHTML=`<div class="row" style="border:0"><b>Notifications</b><button data-a="nclear">Clear all</button></div>`+(S.notifs.length?Object.entries(gr).map(([a,l])=>`<div class="mu" style="margin:8px 0 4px">${a}</div>`+l.map(n=>`<div class="nt ${n.read?"":"unr"}" style="margin-bottom:6px"><b>${n.title}</b><br><small>${n.body}</small><br><small>${time(new Date(n.t))}</small><button class="x" data-a="ndel" data-v="${n.id}">${I("x",12)}</button></div>`).join("")).join(""):'<div class="mu pad">You are all caught up.</div>')}
/* ---------- Actions: UI actions (data-a) and global listeners ---------- */
const ACT={
 panel(){document.body.classList.toggle("pan")},
 app(v){const w=W[v];if(w&&foc===v&&!w.el.classList.contains("min")){w.el.classList.add("min");foc=null}else open(v)},
 trash(){filesGo("trash")},
 start(){toggleOverlay("start",startR)},
 cc(){toggleOverlay("cc",ccR)},
 nc(){toggleOverlay("nc",ncR);if($("#nc"))S.notifs.forEach(n=>n.read=true)},
 switcher(){if($("#sw"))return $("#sw").remove();const s=document.createElement("div");s.id="sw";const ids=[...new Set([...Object.keys(W),...recent])].filter(k=>APPS[k]);
  s.innerHTML=ids.length?ids.map(k=>`<div class="card" data-a="app" data-v="${k}"><div style="display:grid;place-items:center;margin-bottom:8px">${tile(k,48)}</div><b>${APPS[k].t}</b><br><small class="mu">${W[k]?(W[k].el.classList.contains("min")?"Minimized":"Open"):"Recent"}</small></div>`).join(""):"<div>No recent apps</div>";
  s.onclick=e=>{if(e.target===s)s.remove()};$("#screen").append(s)},
 sysmenu(v,b){const r=b.getBoundingClientRect();ctxMenu(r.left,r.bottom+4,[["About CapeOS",()=>{ACT.sec("System");emit()}],["Settings",()=>{ACT.sec("Personalization");emit()}],["Lock screen",()=>{ACT.lockNow();emit()}],["Restart…",()=>D.restart()],["Shut down…",()=>D.shut()]])},
 powermenu(v,b){const r=b.getBoundingClientRect();ctxMenu(r.left,r.top-120,[["Lock screen",()=>{ACT.lockNow();emit()}],["Restart…",()=>D.restart()],["Shut down…",()=>D.shut()]])},
 tg(k){const v=!S[k];if(k==="air")return v?D.airOn():D.airOff();if(k==="wifi")return v?D.wifiOn():D.wifiOff();
  if(k==="bt"){if(S.air)return toast("Turn off airplane mode first");S.bt=v;if(!v)S.btd=false;return notify("Bluetooth","Bluetooth "+(v?"on":"off"),"")}
  if(k==="rec"){S.rec=v;return notify("System",v?"Screen recording started":"Screen recording stopped","Simulated. Nothing is recorded.")}
  S[k]=v;if(k==="saver")notify("Battery","Battery saver "+(v?"on":"off"),"");if(k==="dnd"&&v)toast("Focus is on")},
 lockNow(){S.locked=true;closeOverlays();lockShow()},
 opn(v){open(v)},
 sec(v){secV=v;open("settings");W.settings&&APPS.settings.r(W.settings.c)},
 acc(v){S.acc=v},wall(v){S.wall=+v},engine(v){S.engine=v},out(v){S.out=v},
 wup(v){const i=S.wo.indexOf(v);if(i>0)[S.wo[i-1],S.wo[i]]=[S.wo[i],S.wo[i-1]]},
 nclear(){S.notifs=[]},ndel(v){S.notifs=S.notifs.filter(n=>n.id!=v)},
 defaults(){resetSettings()},
 mtog(){mToggle()},
 unin(v){S.inst=S.inst.filter(x=>x!==v);closeWin(v);notify("System",APPS[v].t+" removed","Uninstalled from this device.")},
 perm(v){const[a,p]=v.split(".");S.perm[a][p]=S.perm[a][p]?0:1;logA(a,(S.perm[a][p]?"Granted ":"Revoked ")+p+" access");if(!S.perm[a][p]){if(p==="cam"&&a==="Meetly")S.cam=false;if(p==="mic"&&a==="Meetly")S.mic=false}}};
document.addEventListener("click",e=>{const t=e.target;$("#ctx")?.remove();
 if(!t.closest("#cc,#nc,#bar"))["#cc","#nc"].forEach(s=>$(s)?.remove());
 if(!t.closest("#start,[data-a=start]"))$("#start")?.remove();
 const b=t.closest("[data-a]");if(!b)return;const a=b.dataset.a;if(a.startsWith("d:"))D[a.slice(2)]();else ACT[a]?.(b.dataset.v,b);emit()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeOverlays();if((e.metaKey||e.ctrlKey)&&e.code==="Space"&&S.pw==="on"&&!S.locked){e.preventDefault();ACT.start();}});
$("#sleep").onclick=()=>D.wake();
setInterval(()=>{if(S.pw==="on"){renderBar();renderWidgets();const l=$("#lclk");if(l)l.textContent=time()}},1000);


document.addEventListener("keydown",e=>{if(S.pw==="on"&&!$("#lock").hidden&&(e.key==="Enter"||e.key===" ")){e.preventDefault();unlock()}});
