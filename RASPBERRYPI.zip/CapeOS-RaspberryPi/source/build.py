#!/usr/bin/env python3
"""Bundle src/ into a single self-contained index.html (static hosting, e.g. Vercel, needs nothing else).
Usage: python3 build.py"""
import pathlib
R = pathlib.Path(__file__).parent
S = R / "src"
ORDER = ["icons", "core", "system", "desktop", "apps/settings", "apps/store", "apps/notes", "apps/calc", "apps/files", "apps/calendar", "apps/clock",
         "apps/gallery", "apps/weather", "apps/reminders", "apps/terminal", "apps/games", "apps/sketch", "apps/sound", "apps/focus", "apps/browser", "main"]
css = (S / "css/style.css").read_text()
js = "\n".join((S / f"js/{n}.js").read_text() for n in ORDER)
html = (S / "index.template.html").read_text().replace("/*CSS*/", css).replace("/*JS*/", js.replace("</script", "<\\/script"))
(R / "index.html").write_text(html)
print("index.html:", len(html) // 1024, "KB")
