#!/usr/bin/env bash
# CapeOS installer for Raspberry Pi OS (Bookworm or newer, 32/64-bit).
# Installs CapeOS to ~/CapeOS and (optionally) makes the Pi start straight into it.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${CAPEOS_DIR:-$HOME/CapeOS}"
AUTOSTART=1
for a in "$@"; do case "$a" in
  --no-autostart) AUTOSTART=0 ;;
  -h|--help) echo "Usage: ./install.sh [--no-autostart]"; echo "  --no-autostart  install only; don't launch CapeOS at login"; exit 0 ;;
  *) echo "Unknown option: $a"; exit 1 ;;
esac; done

say(){ printf '\033[1;34m==>\033[0m %s\n' "$*"; }

# 1. A Chromium browser is needed to display CapeOS.
BROWSER="${CAPEOS_BROWSER:-$(command -v chromium-browser || command -v chromium || true)}"
if [ -z "$BROWSER" ]; then
  if command -v apt-get >/dev/null && [ -z "${CAPEOS_SKIP_APT:-}" ]; then
    say "Installing Chromium (needs sudo)…"
    sudo apt-get update && (sudo apt-get install -y chromium || sudo apt-get install -y chromium-browser)
  else
    echo "Chromium not found. Install it, then run this script again."; exit 1
  fi
fi
command -v python3 >/dev/null || { echo "python3 is required (it ships with Raspberry Pi OS)."; exit 1; }

# 2. Copy the app and create the launcher.
say "Installing CapeOS to $DEST"
mkdir -p "$DEST"
rm -rf "$DEST/app"; cp -r "$HERE/app" "$DEST/app"
cp "$HERE/uninstall.sh" "$DEST/uninstall.sh"
cat > "$DEST/capeos-start" <<'LAUNCH'
#!/usr/bin/env bash
# Starts a tiny local web server for CapeOS, then opens it full screen in Chromium.
# Options: --window  open in a normal window instead of full screen kiosk
ROOT="$(dirname "$(readlink -f "$0")")"; APP="$ROOT/app"; PORT="${CAPEOS_PORT:-8787}"
BROWSER="${CAPEOS_BROWSER:-$(command -v chromium-browser || command -v chromium)}"
[ -n "$BROWSER" ] || { echo "Chromium not found"; exit 1; }
MODE=--kiosk; [ "${1:-}" = "--window" ] && MODE=--app=http://127.0.0.1:$PORT/
SERVER=""
if ! (exec 3<>"/dev/tcp/127.0.0.1/$PORT") 2>/dev/null; then
  python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$APP" >/dev/null 2>&1 &
  SERVER=$!; trap '[ -n "$SERVER" ] && kill "$SERVER" 2>/dev/null' EXIT
fi
for _ in $(seq 1 50); do (exec 3<>"/dev/tcp/127.0.0.1/$PORT") 2>/dev/null && break; sleep 0.1; done
"$BROWSER" $MODE "http://127.0.0.1:$PORT/" \
  --user-data-dir="$HOME/.config/capeos-chromium" \
  --noerrdialogs --disable-infobars --no-first-run --disable-session-crashed-bubble \
  --disable-features=Translate --overscroll-history-navigation=0 --password-store=basic \
  --ozone-platform-hint=auto --autoplay-policy=document-user-activation-required
LAUNCH
chmod +x "$DEST/capeos-start" "$DEST/uninstall.sh"

# 3. Menu / desktop entry, and optional start-at-login.
ICON="$DEST/app/icon.svg"
printf '%s' "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='#5b8def' stroke-width='1.8' stroke-linejoin='round'><rect width='24' height='24' rx='5' fill='#0f1418' stroke='none'/><path d='M12 4c3.4 0 6 1.7 6.8 5-.8 4.2-2.5 7.6-6.8 10-4.3-2.4-6-5.8-6.8-10C6 5.7 8.6 4 12 4zM12 4v16'/></svg>" > "$ICON"
entry(){ cat <<DESK
[Desktop Entry]
Type=Application
Name=CapeOS
Comment=CapeOS desktop demo (full screen)
Exec=$DEST/capeos-start
Icon=$ICON
Terminal=false
Categories=System;
DESK
}
mkdir -p "$HOME/.local/share/applications"; entry > "$HOME/.local/share/applications/capeos.desktop"
if [ -d "$HOME/Desktop" ]; then entry > "$HOME/Desktop/CapeOS.desktop"; chmod +x "$HOME/Desktop/CapeOS.desktop"; fi
if [ "$AUTOSTART" = 1 ]; then
  mkdir -p "$HOME/.config/autostart"; entry > "$HOME/.config/autostart/capeos.desktop"
  say "CapeOS will start automatically at login."
fi
say "Done. Launch it from the menu (Accessories/System > CapeOS), or run: $DEST/capeos-start"
echo "    Exit full screen: Alt+F4.  Uninstall: $DEST/uninstall.sh"
