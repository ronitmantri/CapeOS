CAPEOS FOR RASPBERRY PI OS
==========================

This package runs the exact CapeOS demo on a Raspberry Pi: it installs the app,
starts a small local web server (127.0.0.1 only) and opens CapeOS full screen
in Chromium. It is NOT a bootable disk image: it runs on top of Raspberry Pi OS.

REQUIREMENTS
  - Raspberry Pi 4 or 5 recommended (Pi 3 works but is slower), Raspberry Pi OS
    with desktop (Bookworm or newer). Flash it with Raspberry Pi Imager.
  - Internet only for the first install (to fetch Chromium if missing) and for
    CapeBrowser pages.

INSTALL
  1. Unzip this folder on the Pi.
  2. Open a terminal in it and run:
         chmod +x install.sh uninstall.sh
         ./install.sh
     (use ./install.sh --no-autostart if you don't want it to launch at login)
  3. Launch from the menu (CapeOS), the desktop icon, or:  ~/CapeOS/capeos-start

USE
  - Exit full screen / close: Alt+F4.   Windowed mode: ~/CapeOS/capeos-start --window
  - Change the port if 8787 is taken:    CAPEOS_PORT=9000 ~/CapeOS/capeos-start
  - Your CapeOS data (notes, bookmarks, settings) is kept in a dedicated Chromium profile.
  - To boot straight into CapeOS: enable desktop auto-login in raspi-config
    (System Options > Boot / Auto Login > Desktop Autologin) and keep autostart on.

UNINSTALL
  ~/CapeOS/uninstall.sh

NOTES
  - CapeOS is a simulation. Wi-Fi, Bluetooth, battery and devices shown inside it
    are not your Pi's real hardware.
  - If autostart does nothing on your desktop session, add this line to your
    session's autostart:  ~/CapeOS/capeos-start
  - source/ contains the organized project; edit it and run "python3 build.py"
    to regenerate app/index.html.
